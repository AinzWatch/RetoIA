El repositorio de Github incluye un archivo Readme donde se indiquen cuáles son los archivos a revisar
Aqui se encuentran dos archivos, la linreta de Jupyther y el pdf, en la libreta de Jupytter se pueden observar las graficas y resultados.
