Aqui se encuentran dos archivos, la libreta de Jupyther y el pdf, en la libreta de Jupyter, el usuario puede volver a correr las pruebas dadas por el ejercicio  en el PDF se pueden observar las graficas y resultados. de la operacion

