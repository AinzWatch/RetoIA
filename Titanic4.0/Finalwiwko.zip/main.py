import network
import urequests  # Cambiar a urequests para MicroPython
import machine
import onewire
import ds18x20
import time
import json

# Configuración del sensor de temperatura DS18B20
ds_pin = machine.Pin(4)  # Pin D4 del ESP32
ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))
roms = ds_sensor.scan()

# Configuración de los LEDs
led_verde = machine.Pin(12, machine.Pin.OUT)
led_amarillo = machine.Pin(13, machine.Pin.OUT)
led_rojo = machine.Pin(14, machine.Pin.OUT)

# Conexión a WiFi
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect("Wokwi-GUEST", "")

while not wlan.isconnected():
    pass

print("Conectado a WiFi!")

def enviar_datos(temperatura):
    Tipo = 'temp'
    valor = str(round(temperatura))  # Redondea la temperatura a un número entero y convierte a cadena
    url = f'https://apex.oracle.com/pls/apex/a01198015/senddata/send?tipo={Tipo}&valor={valor}'
    
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; CrOS x86_64 12871.102.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.141 Safari/537.36"
    }
    
    try:
        r = urequests.get(url, headers=headers)  # Usando urequests
        r.close()
    except Exception as e:
        print("Error al enviar datos:", e)

def toggle_estatus_sensor():
    # Estatus: 1 si el sensor está operativo, 0 si no
    url = "https://apex.oracle.com/pls/apex/a01198015/CsensorEstatus/Update"
    
    try:
        r = urequests.get(url)
        r.close()
    except Exception as e:
        print("Error al enviar estatus del sensor:", e)

def get_status_sensor():
    url = "https://apex.oracle.com/pls/apex/a01198015/CsensorEstatus/consulta"
    try:
        r = urequests.get(url)
        estado_sensor = r.json()["items"][0]["bencendido"]
        return estado_sensor

    except Exception as e:
        print("Error al obtener el status del sensor")
        return 0

def controlar_leds(temperatura):
    if temperatura < 25:
        led_verde.on()
        led_amarillo.off()
        led_rojo.off()
    elif 25 <= temperatura < 30:
        led_verde.off()
        led_amarillo.on()
        led_rojo.off()
    else:
        led_verde.off()
        led_amarillo.off()
        led_rojo.on()

def apagar_leds():
    led_verde.off()
    led_amarillo.off()
    led_rojo.off()

while True:
    if get_status_sensor() == 1:
        try:
            ds_sensor.convert_temp()
            time.sleep(1)
            for rom in roms:
                temp = ds_sensor.read_temp(rom)
                print(f"Temperatura: {temp:.2f} °C")
                controlar_leds(temp)
                enviar_datos(temp)
                        
        except Exception as e:
            print("Error en la lectura del sensor:", e)
    else:
        print("Sensor apagado")
        apagar_leds()